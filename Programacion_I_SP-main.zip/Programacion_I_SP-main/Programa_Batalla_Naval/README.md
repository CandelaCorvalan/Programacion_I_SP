# Programa_Batalla_Naval
Proyecto de juego de batalla naval para segundo parcial de programacion.
Práctica para el Segundo Parcial
Desarrollar en Python:
Videojuego Batalla Naval, que tendrá los siguientes datos:

Matriz de 10 filas por 10 columnas.

Datos para llenar la matriz de 10x10.

Datos para colocar cada una de las naves en la matriz.

Dificultad:

Nivel Fácil: 10x10.

Nivel Medio: 20x20 y duplicar la cantidad de naves.

Nivel Difícil: 40x40 y triplicar la cantidad de naves.

Requerimientos
A. Estado inicial
Función para crear dinámicamente una matriz 10x10 con:

0: agua

1 consecutivos: naves (horizontales o verticales)
Cantidad de naves:

4 submarinos (1 casillero)

3 destructores (2 casilleros)

2 cruceros (3 casilleros)

1 acorazado (4 casilleros)

B. Pantalla de inicio
Debe tener 4 botones:

Nivel

Jugar

Ver Puntajes

Salir
Además:

Imagen de fondo completa

Sonido de fondo
Al hacer clic en Jugar, inicia el juego.

C. Pantalla de juego

Tablero donde cada casillero representa un elemento de la matriz.

Botón "Reiniciar".

D. Puntaje

Se inicia en 0000.

Disparo errado: -1 punto (puede ser negativo).

Disparo acertado: +5 puntos.

Hundir una nave: +10 puntos por cada casillero que la compone.

Ejemplo: Crucero de 3 casilleros = 3 x 5 (por averiar) + 3 x 10 (por hundir) = 45 puntos.

E. Disparo

Solo se puede disparar una vez por casillero.

F. Resultado del disparo

Acertado:

+5 puntos (avería)

+10 puntos por casillero si se hunde

Errado: -1 punto

G. Reiniciar

Restablece juego y puntaje a 0000.

H. Registro del jugador

Al inicio o fin, pedir Nick del usuario.

Guardar nombre y puntaje en un archivo.

Volver a pantalla de inicio.

I. Ver Puntajes

Mostrar los 3 mejores puntajes con Nick ordenados de mayor a menor.

Botón para volver al menú principal.

OPCIONALES:
Selector de nivel de dificultad.

Botón para activar/desactivar sonido de fondo.

Sonido al disparar (acertado/errado).

Agregar imágenes, sonidos y animaciones.

Condiciones de aprobación:
Aprobación NO Directa:

Tener completos los ítems A, B, C, D, E, F, G.

Aprobación Directa:

Tener completos los ítems A, B, C, D, E, F, G, H e I.
(Los opcionales suman solo si se cumplen todos los anteriores).

NOTAS:
Nota 0: Crear bibliotecas y funciones propias, bien documentadas.

Nota 1: Las naves deben generarse de forma dinámica y aleatoria en cada partida.

Nota 2: El archivo para puntajes y nicks puede ser .txt, .csv o .json.

