import random
from pygame import *
import pygame
import json

def printear_lista_continua(lista:list):
    """Recibe una lista y muestra sus elementos por pantalla.

    Args:
        lista (list): Lista cualquiera.
    """
    for i in range(len(lista)):
        if type(lista[i]) == list:
            printear_lista_continua(lista[i])
        elif i == len(lista):
            print(lista[i])
        else:
            print(lista[i],end=" ")

def printear_matriz(matriz:list):
    """Recibe una matriz y la muestra de forma ordenada.

    Args:
        matriz (list): Matriz a mostrar.
    """
    for f in range(len(matriz)):
        for c in range(len(matriz[f])):
            print(matriz[f][c], end= " ")
        print("")

def bool_aleatorio()->bool:
    """De manera aleatoria retorna un True o False

    Returns:
        bool: True o False de forma aleatoria.
    """
    numero = random.randint(0,1)
    if numero == 0:
        retorno = False
    else:
        retorno = True
    return retorno

def inicializar_matriz(filas:int,columnas:int,valor_inicial=0)->list:
    """Inicializa una matriz con la cantidad de filas y columas ingresadas. Por defecto los elmentos seran ceros pero se le puede pasar por parametro el valor de los elementos iniciales. 

    Args:
        filas (int): Cantidad de filas que tendra la matriz.
        columnas (int): Cantida de columnas que tendra la matriz.
        valor_inicial : Valor inicial que tendran los elementos de la matriz, por defecto en cero.

    Returns:
        list: Retorna la matriz inicializada.
    """
    matriz = []
    for i in range(filas):
        fila = [valor_inicial] * columnas
        matriz += [fila]
    return matriz

def colocar_barco(matriz:list,barco:list)->list:
    """Valida la posicion donde se va a colocar el barco, si la posicion es valida lo coloca y retorna una lista con los datos del barco colocado. Los datos de la lista son: tamaño del barco, coordenada inicial del barco y su posicion(vertical u horizontal).

    Args:
        matriz (list): Tablero donde se colocara el barco.
        barco (list): Barco que se va a colocar en el tablero.

    Returns:
        list: Lista de datos de la colocacion del barco.
    """
    pos = bool_aleatorio()
    posicion_valida = False
    while posicion_valida == False:
        fila = random.randint(0,len(matriz)-1)
        columna = random.randint(0,len(matriz[0])-1)
        for i in range(len(barco)):
            if pos:
                if columna + i >= len(matriz[0]) or matriz[fila][columna + i] == 1:
                    break
                elif matriz[fila][columna + i] == 0 and i == len(barco)-1:
                    posicion_valida = True
            else:
                if fila + i >= len(matriz) or matriz[fila + i][columna] == 1:
                    break
                elif matriz[fila + i][columna] == 0 and i == len(barco)-1:
                    posicion_valida = True
    if posicion_valida:
        for i in range(len(barco)):
            if pos:
                matriz[fila][columna + i] = 1
            else:
                matriz[fila + i][columna] = 1
    coordenada = (fila,columna)
    poscicion = pos
    largo = len(barco)
    #cuadrado = pygame.Rect((20*columna)+20,(20*fila)+100,25,25)            
    datos_barco = [largo,coordenada,poscicion]
    return datos_barco

def colocacion_barcos(matriz:list,barco:list)->list:
    """Coloca uno por uno los barcos en el tablero de juego.

    Args:
        matriz (list): Tablero donde se van a colocar los barcos.
        barco (list): Barcos que se van a colocar.

    Returns:
        list: Retorna una lista con los datos de los barcos colocados.
    """
    lista_datos = []
    if len(barco) == 1:
        for c in range(4):
            datos = colocar_barco(matriz,barco)
            lista_datos.append(datos)
    elif len(barco) == 2:
        for c in range(3):
            datos = colocar_barco(matriz,barco)
            lista_datos.append(datos)
    elif len(barco) == 3:
        for c in range(2):
            datos = colocar_barco(matriz,barco)
            lista_datos.append(datos)
    elif len(barco) == 4:
        datos = colocar_barco(matriz,barco)
        lista_datos.append(datos)
    return lista_datos

def limpiar_datos(lista_barcos:list)->list:
    """Recibe la lista de datos de los barcos y la limpia para dejarla prolija.

    Args:
        lista_barcos (list): Lista de datos de los barcos.

    Returns:
        list: Lista limpia de los datos de los barcos.
    """
    lista_limpia = []
    for i in range(len(lista_barcos)):
        tipos_barcos = lista_barcos[i]
        for f in range(len(tipos_barcos)):
            lista_limpia.append(tipos_barcos[f])
            
    return lista_limpia

def tablero_juego(dificultad:str="F")->list:
    """Genera el juego y el tablero real donde se colocan los barcos, retorna una lista con el tablero de barcos y una lista de los datos de los barcos. 

    Args:
        dificultad (str, optional): Dificultad que tendra el juego. Defaults to "F".

    Returns:
        list: Lista con tablero real del juego y la lista de barcos.
    """
    filas = 10
    columnas = 10
    repeticiones = 1
    if dificultad == "M":
        filas *= 2
        columnas *= 2
        repeticiones *= 2
    elif dificultad == "D":
        filas *= 4
        columnas *= 4
        repeticiones *= 3

    submarino = [1]
    destructore = [1,1]
    crucero = [1,1,1]
    acorazado =[1,1,1,1]
    barcos = [submarino,destructore,crucero,acorazado]

    tablero = inicializar_matriz(filas,columnas)
    informacion_tablero = False
    for r in range(repeticiones):
        for barco in barcos:
            if informacion_tablero == False:
                info_barcos = [colocacion_barcos(tablero,barco)]
                informacion_tablero = True
            else:
                datos = colocacion_barcos(tablero,barco)
                info_barcos.append(datos)

    lista_limpia = limpiar_datos(info_barcos)

    tablero_info = [tablero,lista_limpia]
    return tablero_info

def generar_casilleros(matriz:list,ancho:int,alto:int)->list:
    """Genera los casilleros que se van a mostrar en la pantalla, ajusta el tamaño de los casilleros generados segun el tamaño de la ventana, retorna una lista con todos los datos de cada uno de los casilleros generados.

    Args:
        matriz (list): Tablero de juego.
        ancho (int): Dimensiones de la pantalla.
        alto (int): Dimensiones de la pantalla.

    Returns:
        list: Lista de casilleros.
    """
    filas = len(matriz)
    columnas = len(matriz[0])
    margen_x = 50
    margen_y = 120
    area_disponible_x = ancho - (2 * margen_x)
    area_disponible_y = alto - margen_y - 50
    tamaño_casillero_x = area_disponible_x // columnas
    tamaño_casillero_y = area_disponible_y // filas
    tamaño_casillero = min(tamaño_casillero_x, tamaño_casillero_y)
    tamaño_casillero = max(15, min(tamaño_casillero, 40))
    tablero_ancho = columnas * tamaño_casillero
    tablero_alto = filas * tamaño_casillero
    inicio_x = (ancho - tablero_ancho) // 2
    inicio_y = margen_y + (area_disponible_y - tablero_alto) // 2
    lista_casilleros = []
    for f in range(filas):
        for c in range(columnas):
            x = inicio_x + (c * tamaño_casillero)
            y = inicio_y + (f * tamaño_casillero)
            cuadrado = pygame.Rect(x, y, tamaño_casillero - 1, tamaño_casillero - 1)
            casillero = [cuadrado, True, None]  # Ahora es una lista con color
            lista_casilleros.append(casillero)
    return lista_casilleros

def centrar_eje_x(superfice, objeto_a_centrar)->int:
    """Se encarga de centrar un objeto en su eje X.

    Args:
        superfice : Superficie donde se va a centrar.
        objeto_a_centrar : Objeto que se va a centrar.
    Returns:
        int: centro del eje X.
    """
    centro = superfice.x +(superfice.width - objeto_a_centrar.get_width())/2
    return centro

def centrar_eje_y(superfice, objeto_a_centrar)->int:
    """Se encarga de centrar un objeto en su eje Y.

    Args:
        superfice : Superficie donde se va a centrar.
        objeto_a_centrar : Objeto que se va a centrar.
    Returns:
        int: centro del eje Y.
    """
    centro = superfice.y +(superfice.height - objeto_a_centrar.get_height())/2
    return centro

def poner_boton(screen, boton, palabra:str, color_apretado, color_no_apretado, fuente):
    """Se encarga de poner un boton en la pantalla.

    Args:
        screen : pantalla donde se colocara el boton.
        boton : boton a colocar.(El boton ya debe estar creado con su posicion y tamaño.)
        palabra (str): texto del boton.
        color_apretado : color del boton.
        color_no_apretado : color del boton al posicionarse encima.
        fuente : fuente del texto.
    """
    if boton.collidepoint(mouse.get_pos()):
        draw.rect(screen,(color_apretado), boton, 0)
    else:
        draw.rect(screen,(color_no_apretado), boton, 0)
    texto = fuente.render(palabra, True, ("white"))
    screen.blit(texto,(centrar_eje_x(boton,texto),centrar_eje_y(boton,texto)))

def cargar_imagen(ruta:str,medidas:tuple)->surface:
    """Carga una imagen y ajusta la imagen a las medidas requeridas.

    Args:
        ruta (str): Ruta de la imagen.
        medidas (tuple): Medidas de la pantalla.

    Returns:
        surface: Imagen ajustada a la pantalla.
    """
    imagen = pygame.image.load(ruta)
    imagen_transformada = pygame.transform.scale(imagen,medidas)
    return imagen_transformada


def escribir_texto(screen,text:str, pos:tuple=(0,0), size:int=16, color:tuple=(0,0,0)):
    """Escribe un texto en la pantalla, se puede pasar por parametro la posicion, el tamaño y el color del texto.

    Args:
        screen: Pantalla donde se mostrara el texto.
        text (str): Texto que se va a mostrar.
        pos (tuple, optional): Posicion donde se va a mostrar el texto. Defaults to (0,0).
        size (int, optional): Tamaño del texto a mostrar. Defaults to 16.
        color (tuple, optional): Color del texto a mostrar. Defaults to (0,0,0).
    """
    font = pygame.font.SysFont("Consolas", size)
    screen.blit(font.render(text, True, color), pos)


def obtener_mejores_puntajes(cantidad=3,ruta='puntajes.json')->list|bool:
    """Lee el archivo de puntajes si es que existe, si existe, por defecto retorna los mejores 3 puntajes, sino retorna False.

    Args:
        cantidad (int, optional): Cantidad de puntajes a retornar. Defaults to 3.
        ruta (str, optional): Ruta del archivo de puntajes. Defaults to 'puntajes.json'.

    Returns:
        list|bool: Lista de mejores puntajes. | False.
    """
    puntajes = []
    try:
        with open(ruta, 'r') as archivo:
            for linea in archivo:
                partes = linea.strip().split(',')
                if len(partes) == 2:
                    nombre, puntos = partes
                    puntajes.append((nombre, int(puntos)))
    except FileNotFoundError:
        pass
    puntajes.sort(key=lambda x: x[1], reverse=True)
    if len(puntajes) > 0:
        retorno = puntajes[:cantidad]
    else:
        retorno = False
    return retorno

def guardar_puntaje(nick:str, puntaje:int, ruta:str='puntajes.json'):
    """Guarda el puntaje de la partida, junto con el nickname del jugador.

    Args:
        nick (str): Nombre del jugador.
        puntaje (int): Puntaje de la partida.
        ruta (str, optional): Ruta del archivo de puntajes. Defaults to 'puntajes.json'.
    """
    with open(ruta, 'a') as puntajes:
        puntajes.write(f'{nick},{puntaje}\n')

def iniciar_nueva_partida(dificultad:str,ancho:int,alto:int)->list:
    """Crea una partida nueva y retorna una lista con todos los datos del juego. La lista contiene el tablero de juego real, el tablero que se mostrara en pantalla, la lista con los datos de los barcos, la lista con el estado de los barcos, lista de los casilleros del juego, el puntaje inicial del juego y los disparos iniciales del juego. 
    
    Args:
        dificultad (str): dificultad que tendra el juego.
        ancho (int): dimensiones de la ventana.
        alto (int): dimensiones de la ventana.

    Returns:
        list: Lista con todos los datos del juego generado.
    """
    juego = tablero_juego(dificultad)
    tablero_real = juego[0]
    lista_barcos = juego[1]
    tablero_covertura = inicializar_matriz(len(tablero_real),len(tablero_real[0]))
    lista_casilleros = generar_casilleros(tablero_real,ancho,alto)
    barcos_estado = [barco[0] for barco in lista_barcos]
    puntaje = 0
    disparos_realizados = 0
    datos_juego = [tablero_real, lista_barcos, tablero_covertura, lista_casilleros, barcos_estado, puntaje, disparos_realizados]
    return datos_juego
